---

# Hospital Patient Triage and Bed Allocator System

A comprehensive **Operating Systems simulation project** built entirely in **C for Linux/POSIX environments**.  
This project simulates a high-concurrency hospital triage and admission system to demonstrate practical implementation of core Operating System concepts.

## Table of Contents
- [Project Overview](#project-overview)
- [Core Operating System Concepts](#core-operating-system-concepts)
- [System Architecture](#system-architecture)
- [Development Phases](#development-phases)
- [Technical Stack](#technical-stack)
- [Project Structure](#project-structure)
- [Compilation and Execution](#compilation-and-execution)
- [Future Improvements](#future-improvements)

---

## Project Overview
This system acts as a low-level backend server that manages patient admissions, bed allocation, and resource synchronization. It is designed to handle high-concurrency scenarios using system-level Linux APIs.

---

## Core Operating System Concepts
The implementation covers the following technical domains:
* Process Creation & Management
* Inter-Process Communication (IPC) via FIFOs
* CPU Scheduling (SJF, Priority)
* Multithreading (POSIX Threads)
* Synchronization (Mutex, Semaphores, Condition Variables)
* Dynamic Memory Management (Best-Fit, First-Fit)
* Virtual Memory Mapping (`mmap`)

---

## System Architecture

```text
               +----------------------+
               |  Patient Simulators  |
               +----------+-----------+
                          |
                          | FIFO PIPE
                          v
              +-----------------------+
              |  Receptionist Thread  |
              +-----------+-----------+
                          |
                          v
              +-----------------------+
              |  Scheduler Thread     |
              +-----------+-----------+
                          |
          +---------------+---------------+
          |                               |
          v                               v
+-------------------+         +-------------------+
| ICU Nurse Thread  |         | Ward Nurse Thread |
+-------------------+         +-------------------+
```

---

## Development Phases

### Phase 1: Process Management & IPC
Builds a multi-process environment where independent patient simulators are spawned using `fork()` and `execv()`. Communication is handled through Linux Named Pipes (FIFOs) located at `/tmp/triage_pipe`.

### Phase 2: CPU Scheduling Simulation
Handles patient overflow via an automated scheduling engine.
* **Algorithms:** SJF (Shortest Job First) to minimize average wait time and Priority Scheduling for medical triage.
* **Metrics:** Calculates Average Waiting Time and Turnaround Time (TAT).
* **Interface:** ANSI-colored terminal dashboard with Gantt-chart timelines.

### Phase 3: POSIX Threads & Synchronization
Transforms the architecture into a multithreaded server utilizing a Thread Pool (Receptionist, Scheduler, and Nurse threads).
*   **Synchronization:** Uses `pthread_mutex_t` for resource protection and `sem_t` for capacity limits.
*   **Efficiency:** Employs `pthread_cond_t` to solve the Producer-Consumer problem without busy-waiting.

### Phase 4: Dynamic Memory Management
Models hospital wards as contiguous memory blocks.
*   **Allocation:** Supports First-Fit, Best-Fit, and Worst-Fit strategies.
*   **Optimization:** Implements automatic Left/Right Coalescing and Defragmentation.
*   **I/O:** Uses `mmap()` and `msync()` for virtual memory logging to reduce standard I/O overhead.

---

## Technical Stack

| Component | Technology |
| :--- | :--- |
| Language | C (C99/C11) |
| Environment | Linux / POSIX |
| Build Tool | GNU Make |
| Authors | 23F-0787 Muskan | 23F-0509 Abdullah | 23F-0532 Moeed |

---

## Project Structure
```text
.
├── Makefile                   # Build configuration
├── patient_simulator.c       # Client simulation logic
├── triage_server.c           # Main server implementation
├── scheduler_sim.c           # Scheduling algorithms
├── memory_sim.c              # Memory management simulation
├── script/
│   ├── start_hospital.sh     # Server startup script
│   └── stress_test.sh        # Concurrency testing script
├── logs/                      # System logs
└── README.md
```

---

## Compilation and Execution

### Build
Bash
```bash
make clean
make

### Running the Server
```bash
./script/start_hospital.sh
```

### Running Stress Tests
```bash
./script/stress_test.sh
```

### Memory Simulation (Standalone)
```bash
./memory_sim --strategy [best | first | worst]
```

---

## Future Improvements
*   Implementation of Shared Memory IPC.
*   Real-time Scheduling Algorithms.
*   Network-based Patient Admission (Socket Programming).
*   Deadlock Detection Module.
*   Distributed Hospital Cluster Simulation.

---

