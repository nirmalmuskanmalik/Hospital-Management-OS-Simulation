#!/bin/bash
# ================================================================================
# Project : Hospital Patient Triage & Bed Allocator
# Script  : triage.sh
# Group   : Group VII
# Member  : Nirmal Muskan [23F-0787] , Muhammad Abdullah [23F-0509] , Abdul Moeed [23F-0532]
# Purpose : Patient intake, validation, and priority mapping
# ================================================================================

NAME=$1
AGE=$2
SEVERITY=$3

# 1. Validate Inputs (Check for empty or non-numeric)
if [[ -z "$NAME" || ! "$AGE" =~ ^[0-9]+$ || ! "$SEVERITY" =~ ^[0-9]+$ ]]; then
    echo "Usage: ./triage.sh [Name] [Age] [Severity 1-10]"
    exit 1
fi

# 2. Map Severity to Priority (Using the manual's table)
if (( SEVERITY >= 9 )); then
    PRIORITY=1
elif (( SEVERITY >= 7 )); then
    PRIORITY=2
elif (( SEVERITY >= 5 )); then
    PRIORITY=3
elif (( SEVERITY >= 3 )); then
    PRIORITY=4
else
    PRIORITY=5
fi

# 3. Format and Pipe to Admissions Manager
RECORD="$NAME|$AGE|P$PRIORITY"
echo "$RECORD" > /tmp/triage_pipe

# 4. Output for the Lab Report
echo "-------------------------------------------------------"
echo "Patient Intake Validated: $NAME"
echo "Age: $AGE | Symptom Severity: $SEVERITY"
echo "Mapped Triage Priority: $PRIORITY"
echo "Status: Dispatched to Admissions Manager via FIFO"
echo "-------------------------------------------------------"
