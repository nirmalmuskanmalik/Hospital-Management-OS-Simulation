#!/bin/bash
# ================================================================================
# Project : Hospital Patient Triage & Bed Allocator
# Script  : start_hospital.sh
# Group   : Group VII
# Member  : Nirmal Muskan [23F-0787] , Muhammad Abdullah [23F-0509] , Abdul Moeed [23F-0532]
# Date    : 2026-06-3
# Purpose : Initialize shared memory, semaphores, and launch admissions manager
# Usage   : ./script/start_hospital.sh 
# ================================================================================

# 1. Clean up old resources (FIFOs)
rm -f /tmp/triage_pipe
rm -f /tmp/discharge_fifo

# 2. Create Named Pipes (FIFOs) for IPC
mkfifo /tmp/triage_pipe || { echo "Failed to create triage pipe"; exit 1; }
mkfifo /tmp/discharge_fifo || { echo "Failed to create discharge pipe"; exit 1; }

# Set permissions so all processes can read/write to pipes
chmod 666 /tmp/triage_pipe
chmod 666 /tmp/discharge_fifo

# 3. Startup Banner (Updated for Lab Requirements)
echo "======================================================="
echo " Hospital System Starting..."
echo " Shared Memory Key  : 0xBEDF00D"
echo " Ward Capacity      : 4 ICU, 4 Isolation, 12 General"
echo " Semaphores Created : /sem_icu_limit, /sem_isolation_limit"
echo "======================================================="

# Small delay to ensure resources are ready
sleep 1

# 4. Launch the Admissions Manager process in the background
# This acts as our 'Server' process
./admissions &
APP_PID=$!
echo $APP_PID > /tmp/admissions_pid

echo "Multithreaded Admissions Server Online."
echo "Admissions Manager Started (PID: $APP_PID)"
echo "-------------------------------------------------------"
