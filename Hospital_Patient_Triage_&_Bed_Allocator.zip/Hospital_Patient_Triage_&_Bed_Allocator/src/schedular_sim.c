#include <stdio.h>
#include <stdlib.h>

typedef struct {
    int id;
    int priority;
    int burst_time; 
    int wait_time;
    int turnaround_time;
} Process;

// Helper to calculate and log metrics
void simulate(FILE* log, Process procs[], int n, const char* algo_name) {
    int total_wt = 0, total_tat = 0;
    int current_time = 0;

    // Header Interface
    printf("\n\033[1;33m[ SYSTEM ] Executing: %s\033[0m\n", algo_name);
    printf("----------------------------------------------------------------------\n");
    fprintf(log, "--- %s ---\n", algo_name);
    
    // Gantt Chart Interface
    printf("Timeline: ");
    printf("\033[1;32m[0]\033[0m");
    fprintf(log, "Gantt Chart: [0]");

    for (int i = 0; i < n; i++) {
        procs[i].wait_time = current_time;
        procs[i].turnaround_time = procs[i].wait_time + procs[i].burst_time;
        current_time += procs[i].burst_time;
        
        total_wt += procs[i].wait_time;
        total_tat += procs[i].turnaround_time;

        printf(" == \033[1;36m(P%d)\033[0m == [%d]", procs[i].id, current_time);
        fprintf(log, " == (P%d) == [%d]", procs[i].id, current_time);
    }

    // Table Header
    printf("\n\n%-12s | %-10s | %-10s | %-8s | %-8s\n", "PATIENT", "PRIORITY", "BURST", "WAIT", "TAT");
    printf("----------------------------------------------------------------------\n");

    for (int i = 0; i < n; i++) {
        printf("Patient %-4d | P-%-8d | %-10d | %-8d | %-8d\n", 
                procs[i].id, procs[i].priority, procs[i].burst_time, procs[i].wait_time, procs[i].turnaround_time);
        
        fprintf(log, "P%d | Priority: %d | Burst: %d | Wait: %d | TAT: %d\n", 
                procs[i].id, procs[i].priority, procs[i].burst_time, procs[i].wait_time, procs[i].turnaround_time);
    }
    
    printf("----------------------------------------------------------------------\n");
    printf("\033[1;32mAverage Waiting Time    :\033[0m %.2f\n", (float)total_wt / n);
    printf("\033[1;32mAverage Turnaround Time :\033[0m %.2f\n", (float)total_tat / n);
    printf("----------------------------------------------------------------------\n");
    
    fprintf(log, "\nAvg Wait: %.2f | Avg TAT: %.2f\n\n", (float)total_wt / n, (float)total_tat / n);
}

int main() {
    FILE *log = fopen("logs/schedule_log.txt", "w");
    if (!log) return 1;

    // Group Identity Header
    printf("\033[1;34m"); // Blue Color
    printf("**********************************************************************\n");
    printf("* HOSPITAL PATIENT TRIAGE & BED ALLOCATOR                            *\n");
    printf("* ------------------------------------------------------------------ *\n");
    printf("* AUTHORS: 23F-0787 Nirmal Muskan| 23F-0509 Muhammad Abdullah | 23F-0532 Abdul Moeed *\n");
    printf("**********************************************************************\n");
    printf("\033[0m"); // Reset Color

    // Data Set
    Process patient_data[] = {
        {101, 2, 6, 0, 0}, {102, 1, 9, 0, 0}, {103, 4, 3, 0, 0}, {104, 3, 5, 0, 0}, {105, 1, 4, 0, 0}
    };
    int n = sizeof(patient_data) / sizeof(patient_data[0]);

    // 1. SHORTEST JOB FIRST (SJF) LOGIC
    // Creating a copy for SJF
    Process sjf_queue[n];
    for(int i=0; i<n; i++) sjf_queue[i] = patient_data[i];

    // Sort by Burst Time (Smallest first)
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (sjf_queue[j].burst_time > sjf_queue[j+1].burst_time) {
                Process temp = sjf_queue[j];
                sjf_queue[j] = sjf_queue[j+1];
                sjf_queue[j+1] = temp;
            }
        }
    }
    simulate(log, sjf_queue, n, "SHORTEST JOB FIRST (SJF)");


    // 2. PRIORITY-BASED ALLOCATION LOGIC
    // Creating a copy for Priority
    Process priority_queue[n];
    for(int i=0; i<n; i++) priority_queue[i] = patient_data[i];

    // Priority Sort (Bubble Sort - Lowest number is highest priority)
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (priority_queue[j].priority > priority_queue[j+1].priority) {
                Process temp = priority_queue[j];
                priority_queue[j] = priority_queue[j+1];
                priority_queue[j+1] = temp;
            }
        }
    }
    simulate(log, priority_queue, n, "PRIORITY-BASED ALLOCATION");

    printf("\n\033[1;35m[ INFO ] Results successfully exported to logs/schedule_log.txt\033[0m\n\n");
    fclose(log);
    return 0;
}
